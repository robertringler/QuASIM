# QDL Language Reference

QDL is a deterministic DSL with arithmetic, worldmodel calls, simulation kernels, and safety guards.